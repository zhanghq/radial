﻿using Microsoft.Practices.Unity;
using Radial;
using Radial.Persist;
using Radial.Persist.Nhs;
using Radial.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using $safeprojectname$.Infras.Persist;
using $safeprojectname$.Infras.Persist.Initializer;
using $safeprojectname$.Domain.Repos;
using $safeprojectname$.Infras.Repos.SqlClient;

namespace $safeprojectname$.Startup
{
    /// <summary>
    /// SqlClientBootTask
    /// </summary>
    public class SqlClientBootTask : GeneralBootTask
    {
        public override void Initialize()
        {
            base.Initialize();

            Components.Container.RegisterType<IFactoryPoolInitializer, SqlClientFactoryPoolInitializer>(new ContainerControlledLifetimeManager());

            //Your code here
            Components.Container.RegisterType<IUserRepository, UserRepository>();
        }
    }
}
